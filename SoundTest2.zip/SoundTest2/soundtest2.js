(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"soundtest2_atlas_", frames: [[1977,55,53,53],[1717,260,54,54],[1977,110,53,53],[1977,0,54,53],[392,737,54,54],[1154,922,198,136],[392,475,80,260],[0,953,250,206],[856,879,296,113],[1559,682,140,297],[867,730,364,147],[1319,504,408,176],[867,338,450,390],[1701,760,194,194],[475,0,619,336],[1096,0,619,336],[1717,0,258,258],[1785,260,258,258],[475,338,390,476],[0,475,390,476],[392,816,230,230],[624,816,230,230],[1701,956,194,194],[0,0,473,473],[1233,730,54,54],[1977,165,53,53],[1233,786,54,54],[1233,842,54,54],[1729,520,238,238],[1319,682,238,238],[1319,338,464,164]]}
];


// symbols:



(lib.CachedBmp_100 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_98 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_97 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_90 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_102 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_87 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_86 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_85 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_84 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_83 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_82 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_81 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_80 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_79 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_78 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_77 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_76 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_75 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_74 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_73 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_72 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_71 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_70 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_69 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_67 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_64 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_63 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_68 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_60 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_58 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedBmp_57 = function() {
	this.initialize(ss["soundtest2_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.Tween3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_102();
	this.instance.setTransform(63.9,-164.9,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_102();
	this.instance_1.setTransform(146.9,-59.9,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_100();
	this.instance_2.setTransform(134.75,57.9,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_102();
	this.instance_3.setTransform(44.9,129,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_98();
	this.instance_4.setTransform(-109.95,116.9,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_97();
	this.instance_5.setTransform(-189,46.05,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_102();
	this.instance_6.setTransform(-172.05,-111.9,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_102();
	this.instance_7.setTransform(7.9,-178.9,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_102();
	this.instance_8.setTransform(159.9,-103.9,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_102();
	this.instance_9.setTransform(163.9,21.05,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_102();
	this.instance_10.setTransform(79.9,111,0.5,0.5);

	this.instance_11 = new lib.CachedBmp_102();
	this.instance_11.setTransform(-47.05,148,0.5,0.5);

	this.instance_12 = new lib.CachedBmp_90();
	this.instance_12.setTransform(-183,88.05,0.5,0.5);

	this.instance_13 = new lib.CachedBmp_102();
	this.instance_13.setTransform(-209,-55.9,0.5,0.5);

	this.instance_14 = new lib.CachedBmp_102();
	this.instance_14.setTransform(-119.05,-178.9,0.5,0.5);

	this.instance_15 = new lib.CachedBmp_87();
	this.instance_15.setTransform(22.9,47.95,0.5,0.5);

	this.instance_16 = new lib.CachedBmp_86();
	this.instance_16.setTransform(-21.15,49,0.5,0.5);

	this.instance_17 = new lib.CachedBmp_85();
	this.instance_17.setTransform(-163.3,19.95,0.5,0.5);

	this.instance_18 = new lib.CachedBmp_84();
	this.instance_18.setTransform(-204.9,-35.45,0.5,0.5);

	this.instance_19 = new lib.CachedBmp_83();
	this.instance_19.setTransform(-93.2,-176.35,0.5,0.5);

	this.instance_20 = new lib.CachedBmp_82();
	this.instance_20.setTransform(27.15,-30.1,0.5,0.5);

	this.instance_21 = new lib.CachedBmp_81();
	this.instance_21.setTransform(-12,-116.25,0.5,0.5);

	this.instance_22 = new lib.CachedBmp_80();
	this.instance_22.setTransform(-116.1,-96.8,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_22},{t:this.instance_21},{t:this.instance_20},{t:this.instance_19},{t:this.instance_18},{t:this.instance_17},{t:this.instance_16},{t:this.instance_15},{t:this.instance_14},{t:this.instance_13},{t:this.instance_12},{t:this.instance_11},{t:this.instance_10},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-209,-178.9,418.2,357.9);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_79();
	this.instance.setTransform(-48.5,-48.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-48.5,-48.5,97,97);


(lib.RedButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_2 = function() {
		playSound("Bell");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(2));

	// Layer_1
	this.instance = new lib.CachedBmp_75();
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_76();
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_77();
	this.instance_2.setTransform(-65.3,-11.15,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_78();
	this.instance_3.setTransform(-65.3,-11.15,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-65.3,-11.1,309.5,168);


(lib.GreenButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_2 = function() {
		playSound("boing");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(2));

	// Layer_1
	this.instance = new lib.CachedBmp_71();
	this.instance.setTransform(-47.5,-39.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_72();
	this.instance_1.setTransform(-47.5,-39.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_73();
	this.instance_2.setTransform(-77.45,-98.85,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_74();
	this.instance_3.setTransform(-77.45,-98.85,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.4,-98.8,195,238);


(lib.greenball = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.CachedBmp_70();
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,97,97);


(lib.BlueButton = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_2 = function() {
		playSound("Go");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(2).call(this.frame_2).wait(2));

	// Layer_1
	this.instance = new lib.CachedBmp_58();
	this.instance.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_1 = new lib.CachedBmp_60();
	this.instance_1.setTransform(-0.5,-0.5,0.5,0.5);

	this.instance_2 = new lib.CachedBmp_68();
	this.instance_2.setTransform(-44.45,17.6,0.5,0.5);

	this.instance_3 = new lib.CachedBmp_67();
	this.instance_3.setTransform(59.15,-39.85,0.5,0.5);

	this.instance_4 = new lib.CachedBmp_68();
	this.instance_4.setTransform(113.5,-4.35,0.5,0.5);

	this.instance_5 = new lib.CachedBmp_68();
	this.instance_5.setTransform(135.5,56.6,0.5,0.5);

	this.instance_6 = new lib.CachedBmp_64();
	this.instance_6.setTransform(92.85,129.3,0.5,0.5);

	this.instance_7 = new lib.CachedBmp_63();
	this.instance_7.setTransform(5.55,126.6,0.5,0.5);

	this.instance_8 = new lib.CachedBmp_68();
	this.instance_8.setTransform(-45.45,66.6,0.5,0.5);

	this.instance_9 = new lib.CachedBmp_68();
	this.instance_9.setTransform(-32.45,-32.35,0.5,0.5);

	this.instance_10 = new lib.CachedBmp_69();
	this.instance_10.setTransform(-54.5,-61.45,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).to({state:[{t:this.instance_1},{t:this.instance_9},{t:this.instance_8},{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2}]},1).to({state:[{t:this.instance_10}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-54.5,-61.4,236.5,236.5);


(lib.Tween2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.greenball("synched",0);
	this.instance.setTransform(-312.7,19.25,1,1,0,0,0,48,48);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-361.2,-29.2,97,97);


(lib.redball = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Tween1("synched",0);
	this.instance.setTransform(48,48);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.5,-0.5,97,97);


(lib.Blue_Clip = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		//code to stop all sounds within createjs
		createjs.Sound.stop();
		playSound("jazzcomedy");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(30));

	// Layer_1
	this.instance = new lib.Tween3("synched",0);
	this.instance.setTransform(-84.4,-66.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({rotation:180},14).to({rotation:0},15).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-299.7,-282.8,439.1,440.6);


// stage content:
(lib.soundtest2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
		
		
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.button_1.addEventListener("click", fl_ClickToGoToAndPlayFromFrame.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame()
		{
			this.gotoAndPlay(1);
		}
		
		
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.button_2.addEventListener("click", fl_ClickToGoToAndPlayFromFrame_2.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame_2()
		{
			this.gotoAndPlay(39);
		}
		
		
		
		
		/* Click to Go to Frame and Stop
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and stops the movie.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		
		this.button_4.addEventListener("click", fl_ClickToGoToAndStopAtFrame_2.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame_2()
		{
			this.gotoAndStop(89);
		}
	}
	this.frame_1 = function() {
		playSound("acousticbreeze2");
	}
	this.frame_29 = function() {
		//code to stop all sounds within createjs
		createjs.Sound.stop();
		
		this.gotoAndStop(0);
	}
	this.frame_39 = function() {
		//code to stop all sounds within createjs
		createjs.Sound.stop();
		playSound("bensoundukulele");
	}
	this.frame_82 = function() {
		//code to stop all sounds within createjs
		createjs.Sound.stop();
	}
	this.frame_83 = function() {
		this.gotoAndStop(0);
	}
	this.frame_89 = function() {
		/* Stop at This Frame
		The  timeline will stop/pause at the frame where you insert this code.
		Can also be used to stop/pause the timeline of movieclips.
		*/
		
		this.stop();
		
		
		
		/* Click to Go to Frame and Stop
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and stops the movie.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		
		this.movieClip_3.addEventListener("click", fl_ClickToGoToAndStopAtFrame.bind(this));
		
		function fl_ClickToGoToAndStopAtFrame()
		{
			
			//code to stop all sounds within createjs
		createjs.Sound.stop();
			this.gotoAndStop(0);
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(28).call(this.frame_29).wait(10).call(this.frame_39).wait(43).call(this.frame_82).wait(1).call(this.frame_83).wait(6).call(this.frame_89).wait(1));

	// Type_L
	this.instance = new lib.CachedBmp_57();
	this.instance.setTransform(186.05,149.55,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(90));

	// RedBut_L
	this.button_2 = new lib.RedButton();
	this.button_2.name = "button_2";
	this.button_2.setTransform(403.95,69,1,1,0,0,0,64,64);
	new cjs.ButtonHelper(this.button_2, 0, 1, 2, false, new lib.RedButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.button_2).to({_off:true},84).wait(6));

	// GreenBut_L
	this.button_1 = new lib.GreenButton();
	this.button_1.name = "button_1";
	this.button_1.setTransform(75.95,197.05);
	new cjs.ButtonHelper(this.button_1, 0, 1, 2, false, new lib.GreenButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.button_1).to({_off:true},84).wait(6));

	// red_layer
	this.instance_1 = new lib.redball("synched",0);
	this.instance_1.setTransform(346.95,66.95,1,1,0,0,0,48,48);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(39).to({_off:false},0).to({y:390.95},44).to({_off:true},1).wait(6));

	// green_layer
	this.instance_2 = new lib.Tween2("synched",0);
	this.instance_2.setTransform(389.65,260.75);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(1).to({_off:false},0).to({x:907.6},28).to({_off:true},1).wait(60));

	// BlueBut_L
	this.button_4 = new lib.BlueButton();
	this.button_4.name = "button_4";
	this.button_4.setTransform(560.9,322,1,1,0,0,0,59,59);
	new cjs.ButtonHelper(this.button_4, 0, 1, 2, false, new lib.BlueButton(), 3);

	this.timeline.addTween(cjs.Tween.get(this.button_4).to({_off:true},1).wait(89));

	// Blue_L
	this.movieClip_3 = new lib.Blue_Clip();
	this.movieClip_3.name = "movieClip_3";
	this.movieClip_3.setTransform(407.95,237,1,1,0,0,0,-84.4,-66.8);
	this.movieClip_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.movieClip_3).wait(89).to({_off:false},0).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(318.5,233.9,345.9,205.6);
// library properties:
lib.properties = {
	id: '66AE49BAF66C41BAB5B024C950EB6F24',
	width: 640,
	height: 480,
	fps: 30,
	color: "#CCCCCC",
	opacity: 1.00,
	manifest: [
		{src:"images/soundtest2_atlas_.png?1644993017980", id:"soundtest2_atlas_"},
		{src:"sounds/acousticbreeze2.mp3?1644993018024", id:"acousticbreeze2"},
		{src:"sounds/Bell.mp3?1644993018024", id:"Bell"},
		{src:"sounds/bensoundukulele.mp3?1644993018024", id:"bensoundukulele"},
		{src:"sounds/boing.mp3?1644993018024", id:"boing"},
		{src:"sounds/Go.mp3?1644993018024", id:"Go"},
		{src:"sounds/jazzcomedy.mp3?1644993018024", id:"jazzcomedy"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['66AE49BAF66C41BAB5B024C950EB6F24'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;